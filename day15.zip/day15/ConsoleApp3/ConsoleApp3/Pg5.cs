﻿using System;
using System.IO;

namespace ConsoleApp3
{
    class Pg5
    {
        static void Main(string[] args)
        {
            string fileName = @"C:\Users\User\Desktop\sample.dat";
            using (BinaryReader r = new BinaryReader(File.Open(fileName, FileMode.Open)))
            {
                Console.WriteLine(r.ReadInt32());
                Console.WriteLine(r.ReadString());
            }
        }
    }
}
