﻿using System;
using System.IO;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream file = new FileStream(@"C:\Users\User\Desktop\myfile.txt", FileMode.Append);

            StreamWriter sw = new StreamWriter(file);

            sw.WriteLine("hello and welcome to the class");
            sw.Close();
            file.Close();
            Console.WriteLine("successfully have written the contents\n\n\n");


           

        }
    }
}
