﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class pg2
    {
        static void Main(string[] args)
        {
            string file1 = @"C:\Users\User\Desktop\myfile.txt";

            StreamReader sr = new StreamReader(file1);
            string[] line = new string[10];
            int i = 0;
            while (!sr.EndOfStream)
            {
                line[i] = sr.ReadLine();
                i++;
            }

            sr.Close();
            Console.WriteLine("Count of lines=" + i);

            foreach(string s in line)
            {
                Console.WriteLine(s);
            }
            
        }
    }
}
