﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class pg11
    {
        static void Main(string[] args)
        {
            int num;
            Console.WriteLine("enter the array elements ");
            num = int.Parse(Console.ReadLine());
            string[] a = new string[num];
            for (int i = 0; i < num; i++)
            {
                Console.WriteLine("Enter string = ");
                a[i] = Console.ReadLine();
            }

            string[] output = a.Where(x => !x.ToLower().Contains("ee")).ToArray();

            Console.WriteLine("\n\nresult\n\n");
            foreach (string x in output)
                Console.WriteLine(x);
        }
    }
}
