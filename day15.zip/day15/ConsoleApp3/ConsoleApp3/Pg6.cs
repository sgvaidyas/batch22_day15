﻿using System;
delegate void Calculate(int a, int b);
namespace ConsoleApp3
{
    class Pg6
    {
        public static void add(int a,int b)
        {
            Console.WriteLine("Sum = " + (a+b));
        }
        public static void sub(int a, int b)
        {
            Console.WriteLine("Diff = " + (a - b));
        }
        public static void mul(int a, int b)
        {
            Console.WriteLine("Prod = " + (a * b));
        }
        public static void quot(int a, int b)
        {
            Console.WriteLine("Quot = " + (a / b));
        }
        static void Main(string[] args)
        {
            Calculate ob = new Calculate(add);
            ob(22, 33);
            Calculate ob1 = new Calculate(mul);
            ob1(2, 33);
        }

    }
}
