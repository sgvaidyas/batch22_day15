﻿using System;
using System.IO;

namespace ConsoleApp3
{
    class Student
    {
        public int id;
        public string name;
    }
    class Pg4
    {
        static void Main(string[] args)
        {
            Student ob = new Student();

            Console.WriteLine("Enter the id and name");
            ob.id = int.Parse(Console.ReadLine());
            ob.name = Console.ReadLine();

            string fileName = @"C:\Users\User\Desktop\sample.dat";
            using (BinaryWriter w = new BinaryWriter(File.Open(fileName, FileMode.Create)))
            {
                w.Write(ob.id);
                w.Write(ob.name);
            }
            Console.WriteLine( "Data entered successfully");
        }
    }
}
