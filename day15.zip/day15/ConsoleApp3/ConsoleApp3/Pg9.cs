﻿using System;

namespace ConsoleApp3
{
    class Pg9
    {
        public static int Sum(int a,int b,int c)
        {
            return a + b + c;
        }
        public static string message(string message1 ,int val )
        {
            return message1 + "   " + val.ToString();
        }
        static void Main(string[] args)
        {
            //all the funtion parameters and return type
            Func<int, int, int, int> add = Sum;

            Console.WriteLine("Result =  " + add(22,3,4));

            Func<string,int,string> m = message;

            Console.WriteLine("The returned val = " +  m("apple",67)    );
        }
    }
}
