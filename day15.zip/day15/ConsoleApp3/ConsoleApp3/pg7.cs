﻿using System;

delegate int Calculator(int a, int b);


namespace ConsoleApp3
{
    class pg7
    {
        public int add(int a,int b)
        {
            return a + b;
        }
        public int mul(int a, int b)
        {
            return a * b;
        }
        static void Main(string[] args)
        {
            pg7 ob = new pg7();
            Calculator ob1 = new Calculator(ob.add);

            Console.WriteLine("Addition  = " + ob1(22,4));
        }
    }
}
