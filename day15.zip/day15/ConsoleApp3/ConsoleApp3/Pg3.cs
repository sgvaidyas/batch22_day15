﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace ConsoleApp3
{
    class Pg3
    {
        static void Main(string[] args)
        {
           
                string file1 = @"C:\Users\User\Desktop\myfile.txt";

                StreamReader sr = new StreamReader(file1);
                // string[] line = new string[10];
                int i = 0;
                while (!sr.EndOfStream)
                {
                    Console.WriteLine(i.ToString() + "   " + (char)sr.Read());
                    i++;
                }

                sr.Close();
                //Console.WriteLine("Count of lines=" + i);


            }
        }
    }

