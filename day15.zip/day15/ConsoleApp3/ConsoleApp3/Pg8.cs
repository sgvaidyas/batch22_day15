﻿using System;
public delegate int Myfun();
namespace ConsoleApp3
{
    class A
    {
        public static int funA()
        {
            int val;
            Console.WriteLine("Class A Enter a value");
            val = int.Parse(Console.ReadLine());
            return val;           
        }
    }
    class B
    {
        public static int funB()
        {
            int val;
            Console.WriteLine("Class B Enter a value");
            val = int.Parse(Console.ReadLine());
            return val;
        }
    }
    class Pg8
    {
        static void Main(string[] args)
        {
            Myfun ob1 = new Myfun(A.funA);
            Myfun ob2 = new Myfun(B.funB);
            Myfun ob3 = new Myfun(B.funB);

            //Console.WriteLine(ob1());
            //Console.WriteLine(ob2());

            Myfun ob4 = ob1 + ob2+ob3;
            Console.WriteLine(ob4());

        }
    }
}
