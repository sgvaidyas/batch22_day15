﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    delegate int Math(int num);
    class pg10
    {
        static void Main(string[] args)
        {
            Math square = x => x * x;

            int res = square(7);
            Console.WriteLine("result  = " + res);

            Math incr = x => x + 2;
            Console.WriteLine("Increemented val = " + incr(5));


            Func<int, int, int> add = (x, y) => x + y;
            Console.WriteLine(add(2, 3));



            int[] arr = { 11, 2, 33, -88, 4, -6, 0, 7, -11 };

            int[] arr2 = arr.Select( x => (x > 0)? x:999).ToArray();

            Console.WriteLine("Positive values");
            foreach (int i in arr2)
            {
                Console.WriteLine(i);
            }



            string[] name = new string[] { "Abhinav","", "shreya", "" ,"shubha" };

            List<string> newnames = new List<string>(name);

            string[] n = newnames.Where(x => x != "").ToArray();

            string[] m = name.Where(x => x != "").ToArray();

            Console.WriteLine("\nARRAY n");
            foreach (string x in n)
                Console.WriteLine(x);

            Console.WriteLine("\nARRAY m");
            foreach (string x in m)
                Console.WriteLine(x);

                       
            Func<int, int, int> max = (x, y) => (x > y)?x:y;

            Func<int, int, int> min = (x, y) => (x < y) ? x : y;

            



        }
    }
}
